#!/bin/sh
./compile.sh Turn.java
./compile.sh Player.java
./compile.sh Maker.java
./compile.sh Breaker.java
./compile.sh SimpleMaker.java
./compile.sh SmartMaker.java
./compile.sh SimpleBreaker.java
./compile.sh MultiRunner.java
./compile.sh Manager.java



