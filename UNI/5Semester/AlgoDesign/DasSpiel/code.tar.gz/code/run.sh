#!/bin/bash
java -cp .:gs-core-1.2.jar:gs-algo-1.2.jar:gs-ui-1.2.jar $*
